Thanks for taking the time to look at Barrenjoey Markets Technology java assessment.

In the package com.barrenjoey.java.bank you will find a hopefully interesting and open exercise. 
Simulating a situation where you are thrown in the deep end without perhaps as much information as you would like.
Please don't be discouraged, use your experience to make some engineering decisions and interpret the requirements
as best you can.

You will find a README file in the  package with more information. Good luck!
