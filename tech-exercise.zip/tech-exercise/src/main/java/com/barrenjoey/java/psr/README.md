Included is a very naive implementation of the game Paper, Scissors, Rock.

Your task to is to refactor this solution and apply SOLID software development principals. You may like to think
about possible future use cases such as game extensions, more players, more rounds e.g best of 3 or even more items beyond
paper, scissors and rock. We will let your imagination and engineering experience guide what you produce.

The code you write should be production quality so please apply any additional aspects (tests etc.) as you see fit.

Enjoy and have fun!