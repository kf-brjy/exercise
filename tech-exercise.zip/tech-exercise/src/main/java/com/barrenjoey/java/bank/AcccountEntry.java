package com.barrenjoey.java.bank;

/**
 * Incomplete AccountEntry class...
 */
public class AcccountEntry {

}
